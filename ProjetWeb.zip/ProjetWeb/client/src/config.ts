export const API_BASE = "http://localhost:4000";
export const USER_EMAIL = "hatimben033@gmail.com";